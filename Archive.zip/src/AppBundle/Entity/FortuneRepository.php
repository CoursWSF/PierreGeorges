<?php

namespace AppBundle\Entity;

class FortuneRepository extends \Doctrine\ORM\EntityRepository
{
  public function findLasts() {
    return $this->createQueryBuilder('F')
      ->orderBy("F.createdAt", "DESC")
      ->setMaxResults(10)
      ->getQuery()
      ->getResult();
  }

  public function bestRated() {
    return $this->createQueryBuilder('F')
      ->orderBy("F.upVote/F.downVote", "DESC")
      ->setMaxResults(10)
      ->getQuery()
      ->getResult();
  }

  public function worstRated() {
    return $this->createQueryBuilder('F')
      ->orderBy("F.downVote/F.upVote", "DESC")
      ->setMaxResults(10)
      ->getQuery()
      ->getResult();
  }
}
