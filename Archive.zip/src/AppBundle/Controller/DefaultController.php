<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // $quotes = $this->getDoctrine()->getRepository("AppBundle:Fortune")->findAll();
        // dump($quotes);

        return $this->render('default/index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'quotes' => $this->getDoctrine()->getRepository("AppBundle:Fortune")->findLasts()
        ));
    }

    /**
     * @Route("/voteup/{id}", name="voteup")
     */
    public function voteUpAction(Request $request, $id)
    {
      $quote = $this->getDoctrine()->getRepository("AppBundle:Fortune")->find($id);

      $quote->voteUp();

      $this->getDoctrine()->getManager()->Flush();
      return $this->redirectToRoute("homepage");
    }

    /**
     * @Route("/votedown/{id}", name="votedown")
     */
    public function voteDownAction(Request $request, $id)
    {
      $quote = $this->getDoctrine()->getRepository("AppBundle:Fortune")->find($id);

      $quote->voteDown();

      $this->getDoctrine()->getManager()->Flush();
      return $this->redirectToRoute("homepage");
    }

    public function showRatedAction(Request $request)
    {
      return $this->render('default/rated.html.twig', array(
          'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
          'bestQuotes' => $this->getDoctrine()->getRepository("AppBundle:Fortune")->bestRated(),
          'worstQuotes' => $this->getDoctrine()->getRepository("AppBundle:Fortune")->worstRated(),
      ));
    }
}
