<?php

/* @WebProfiler/Profiler/body.css.twig */
class __TwigTemplate_169840dbcf0e4655dd7833827b049cff98ba369d6a98653ee9b543352f032a34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15ed79b237222031b7928fc99d9b8f8b54d76ec49c26c218ea156c1c579092d6 = $this->env->getExtension("native_profiler");
        $__internal_15ed79b237222031b7928fc99d9b8f8b54d76ec49c26c218ea156c1c579092d6->enter($__internal_15ed79b237222031b7928fc99d9b8f8b54d76ec49c26c218ea156c1c579092d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/body.css.twig"));

        // line 1
        echo "/*
Copyright (c) 2010, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.com/yui/license.html
version: 3.1.2
build: 56
*/
.sf-reset div,.sf-reset dl,.sf-reset dt,.sf-reset dd,.sf-reset ul,.sf-reset ol,.sf-reset li,.sf-reset h1,.sf-reset h2,.sf-reset h3,.sf-reset h4,.sf-reset h5,.sf-reset h6,.sf-reset pre,.sf-reset code,.sf-reset form,.sf-reset fieldset,.sf-reset legend,.sf-reset input,.sf-reset textarea,.sf-reset p,.sf-reset blockquote,.sf-reset th,.sf-reset td{margin:0;padding:0;}.sf-reset table{border-collapse:collapse;border-spacing:0;}.sf-reset fieldset,.sf-reset img{border:0;}.sf-reset address,.sf-reset caption,.sf-reset cite,.sf-reset code,.sf-reset dfn,.sf-reset em,.sf-reset strong,.sf-reset th,.sf-reset var{font-style:normal;font-weight:normal;}.sf-reset li{list-style:none;}.sf-reset caption,.sf-reset th{text-align:left;}.sf-reset h1,.sf-reset h2,.sf-reset h3,.sf-reset h4,.sf-reset h5,.sf-reset h6{font-size:100%;font-weight:normal;}.sf-reset q:before,.sf-reset q:after{content:'';}.sf-reset abbr,.sf-reset acronym{border:0;font-variant:normal;}.sf-reset sup{vertical-align:text-top;}.sf-reset sub{vertical-align:text-bottom;}.sf-reset input,.sf-reset textarea,.sf-reset select{font-family:inherit;font-size:inherit;font-weight:inherit;}.sf-reset input,.sf-reset textarea,.sf-reset select{font-size:100%;}.sf-reset legend{color:#000;}
.sf-reset abbr {
    border-bottom: 1px dotted #000;
    cursor: help;
}
.sf-reset p {
    font-size: 14px;
    line-height: 20px;
    padding-bottom: 20px;
}
.sf-reset strong {
    color: #313131;
    font-weight: bold;
}
.sf-reset a {
    color: #6c6159;
}
.sf-reset a img {
    border: none;
}
.sf-reset a:hover {
    text-decoration: underline;
}
.sf-reset em {
    font-style: italic;
}
.sf-reset h2,
.sf-reset h3 {
    font-weight: bold;
}
.sf-reset h1 {
    font-family: Georgia, \"Times New Roman\", Times, serif;
    font-size: 20px;
    color: #313131;
    word-break: break-all;
}
.sf-reset li {
    padding-bottom: 10px;
}
.sf-reset .block {
    -moz-border-radius: 16px;
    -webkit-border-radius: 16px;
    border-radius: 16px;
    margin-bottom: 20px;
    background-color: #FFFFFF;
    border: 1px solid #dfdfdf;
    padding: 40px 50px;
}
.sf-reset h2 {
    font-size: 16px;
    font-family: Arial, Helvetica, sans-serif;
}
.sf-reset li a {
    background: none;
    color: #868686;
    text-decoration: none;
}
.sf-reset li a:hover {
    background: none;
    color: #313131;
    text-decoration: underline;
}
.sf-reset ol {
    padding: 10px 0;
}
.sf-reset ol li {
    list-style: decimal;
    margin-left: 20px;
    padding: 2px;
    padding-bottom: 20px;
}
.sf-reset ol ol li {
    list-style-position: inside;
    margin-left: 0;
    white-space: nowrap;
    font-size: 12px;
    padding-bottom: 0;
}
.sf-reset li .selected {
    background-color: #ffd;
}
.sf-button {
    display: -moz-inline-box;
    display: inline-block;
    text-align: center;
    vertical-align: middle;
    border: 0;
    background: transparent none;
    text-transform: uppercase;
    cursor: pointer;
    font: bold 11px Arial, Helvetica, sans-serif;
}
.sf-button span {
    text-decoration: none;
    display: block;
    height: 28px;
    float: left;
}
.sf-button .border-l {
    text-decoration: none;
    display: block;
    height: 28px;
    float: left;
    padding: 0 0 0 7px;
    background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAQtJREFUeNpiPHnyJAMakARiByDWYEGT8ADiYGVlZStubm5xlv///4MEQYoKZGRkQkRERLRYWVl5wYJQyXBZWdkwCQkJUxAHKgaWlAHSLqKiosb//v1DsYMFKGCvoqJiDmQzwXTAJYECulxcXNLoumCSoszMzDzoumDGghQwYZUECWIzkrAkSIIGOmlkLI10AiX//P379x8jIyMTNmPf/v79+ysLCwsvuiQoNi5//fr1Kch4dAyS3P/gwYMTQBP+wxwHw0xA4gkQ73v9+vUZdJ2w1Lf82bNn4iCHCQoKasHsZw4ODgbRIL8c+/Lly5M3b978Y2dn5wC6npkFLXnsAOKLjx49AmUHLYAAAwBoQubG016R5wAAAABJRU5ErkJggg==) no-repeat top left;
}
.sf-button .border-r {
    padding: 0 7px 0 0;
    background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAR1JREFUeNpiPHnyZCMDA8MNID5gZmb2nAEJMH7//v3N169fX969e/cYkL8WqGAHXPLv37//QYzfv39/fvPmzbUnT56sAXInmJub/2H5/x8sx8DCwsIrISFhDmQyPX78+CmQXs70798/BmQsKipqBNTgdvz4cWkmkE5kDATMioqKZkCFdiwg1eiAi4tLGqhQF24nMmBmZuYEigth1QkEbEBxTlySYPvJkwSJ00AnjYylgU6gxB8g/oFVEphkvgLF32KNMmCCewYUv4qhEyj47+HDhyeBzIMYOoEp8CxQw56wsLAncJ1//vz5/P79+2svX74EJc2V4BT58+fPd8CE/QKYHMGJOiIiAp6oWW7evDkNSF8DZYfIyEiU7AAQYACJ2vxVdJW4eQAAAABJRU5ErkJggg==) right top no-repeat;
}
.sf-button .btn-bg {
    padding: 0px 14px;
    color: #636363;
    line-height: 28px;
    background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAcCAYAAACgXdXMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAClJREFUeNpiPnny5EKGf//+/Wf6//8/A4QAcrGzKCZwGc9sa2urBBBgAIbDUoYVp9lmAAAAAElFTkSuQmCC) repeat-x top left;
}
.sf-button:hover .border-l,
.sf-button-selected .border-l {
    background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAR9JREFUeNpi/P//PwMyOHfunDqQSgNiexZkibNnzxYBqZa3HOs5v7PcYQBLnjlzhg1IbfzIdsTjA/t+ht9Mr8GKwZL//v3r+sB+0OMN+zqIEf8gFMvJkyd1gXTOa9YNDP//otrPAtSV/Jp9HfPff78Z0AEL0LUeXxivMfxD0wXTqfjj/2ugkf+wSrL9/YtpJEyS4S8WI5Ek/+GR/POPFjr//cenE6/kP9q4Fo/kr39/mdj+M/zFkGQCSj5i+ccPjLJ/GBgkuYOHQR1sNDpmAkb2LBmWwL///zKCIxwZM0VHR18G6p4uxeLLAA4tJMwEshiou1iMxXaHLGswA+t/YbhORuQUv2DBAnCifvxzI+enP3dQJUFg/vz5sOzgBBBgAPxX9j0YnH4JAAAAAElFTkSuQmCC) no-repeat top left;
}
.sf-button:hover .border-r,
.sf-button-selected .border-r {
    background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAT5JREFUeNpiPHv27BkGBoaDQDzLyMjoJgMSYHrM3WX8hn1d0f///88DFRYhSzIuv2X5H8Rg/SfKIPDTkYH/l80OINffxMTkF9O/f/8ZQPgnwyuGl+wrGd6x7vf49+9fO9jYf3+Bkkj4NesmBqAV+SdPntQC6vzHgIz//gOawbqOGchOxtAJwp8Zr4F0e7D8/fuPAR38/P8eZIo0yz8skv8YvoIk+YE6/zNgAyD7sRqLkPzzjxY6/+HS+R+fTkZ8djLh08lCUCcuSWawJGbwMTGwg7zyBatX2Bj5QZKPsBrLzaICktzN8g/NWEYGZgYZjoC/wMiei5FMpFh8QPSU6Ojoy3Cd7EwiDBJsDgxiLNY7gLrKQGIsHAxSDHxAO2TZ/b8D+TVxcXF9MCtYtLiKLgDpfUDVsxITE1GyA0CAAQA2E/N8VuHyAAAAAABJRU5ErkJggg==) right top no-repeat;
}
.sf-button:hover .btn-bg,
.sf-button-selected .btn-bg {
    color: #FFFFFF;
    text-shadow:0 1px 1px #6b9311;
    background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAcCAIAAAAvP0KbAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAEFJREFUeNpiPnv2LNMdvlymf///M/37B8R/QfQ/MP33L4j+B6Qh7L9//sHpf2h8MA1V+w/KRjYLaDaLCU8vQIABAFO3TxZriO4yAAAAAElFTkSuQmCC) repeat-x top left;
}
";
        
        $__internal_15ed79b237222031b7928fc99d9b8f8b54d76ec49c26c218ea156c1c579092d6->leave($__internal_15ed79b237222031b7928fc99d9b8f8b54d76ec49c26c218ea156c1c579092d6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/body.css.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* /**/
/* Copyright (c) 2010, Yahoo! Inc. All rights reserved.*/
/* Code licensed under the BSD License:*/
/* http://developer.yahoo.com/yui/license.html*/
/* version: 3.1.2*/
/* build: 56*/
/* *//* */
/* .sf-reset div,.sf-reset dl,.sf-reset dt,.sf-reset dd,.sf-reset ul,.sf-reset ol,.sf-reset li,.sf-reset h1,.sf-reset h2,.sf-reset h3,.sf-reset h4,.sf-reset h5,.sf-reset h6,.sf-reset pre,.sf-reset code,.sf-reset form,.sf-reset fieldset,.sf-reset legend,.sf-reset input,.sf-reset textarea,.sf-reset p,.sf-reset blockquote,.sf-reset th,.sf-reset td{margin:0;padding:0;}.sf-reset table{border-collapse:collapse;border-spacing:0;}.sf-reset fieldset,.sf-reset img{border:0;}.sf-reset address,.sf-reset caption,.sf-reset cite,.sf-reset code,.sf-reset dfn,.sf-reset em,.sf-reset strong,.sf-reset th,.sf-reset var{font-style:normal;font-weight:normal;}.sf-reset li{list-style:none;}.sf-reset caption,.sf-reset th{text-align:left;}.sf-reset h1,.sf-reset h2,.sf-reset h3,.sf-reset h4,.sf-reset h5,.sf-reset h6{font-size:100%;font-weight:normal;}.sf-reset q:before,.sf-reset q:after{content:'';}.sf-reset abbr,.sf-reset acronym{border:0;font-variant:normal;}.sf-reset sup{vertical-align:text-top;}.sf-reset sub{vertical-align:text-bottom;}.sf-reset input,.sf-reset textarea,.sf-reset select{font-family:inherit;font-size:inherit;font-weight:inherit;}.sf-reset input,.sf-reset textarea,.sf-reset select{font-size:100%;}.sf-reset legend{color:#000;}*/
/* .sf-reset abbr {*/
/*     border-bottom: 1px dotted #000;*/
/*     cursor: help;*/
/* }*/
/* .sf-reset p {*/
/*     font-size: 14px;*/
/*     line-height: 20px;*/
/*     padding-bottom: 20px;*/
/* }*/
/* .sf-reset strong {*/
/*     color: #313131;*/
/*     font-weight: bold;*/
/* }*/
/* .sf-reset a {*/
/*     color: #6c6159;*/
/* }*/
/* .sf-reset a img {*/
/*     border: none;*/
/* }*/
/* .sf-reset a:hover {*/
/*     text-decoration: underline;*/
/* }*/
/* .sf-reset em {*/
/*     font-style: italic;*/
/* }*/
/* .sf-reset h2,*/
/* .sf-reset h3 {*/
/*     font-weight: bold;*/
/* }*/
/* .sf-reset h1 {*/
/*     font-family: Georgia, "Times New Roman", Times, serif;*/
/*     font-size: 20px;*/
/*     color: #313131;*/
/*     word-break: break-all;*/
/* }*/
/* .sf-reset li {*/
/*     padding-bottom: 10px;*/
/* }*/
/* .sf-reset .block {*/
/*     -moz-border-radius: 16px;*/
/*     -webkit-border-radius: 16px;*/
/*     border-radius: 16px;*/
/*     margin-bottom: 20px;*/
/*     background-color: #FFFFFF;*/
/*     border: 1px solid #dfdfdf;*/
/*     padding: 40px 50px;*/
/* }*/
/* .sf-reset h2 {*/
/*     font-size: 16px;*/
/*     font-family: Arial, Helvetica, sans-serif;*/
/* }*/
/* .sf-reset li a {*/
/*     background: none;*/
/*     color: #868686;*/
/*     text-decoration: none;*/
/* }*/
/* .sf-reset li a:hover {*/
/*     background: none;*/
/*     color: #313131;*/
/*     text-decoration: underline;*/
/* }*/
/* .sf-reset ol {*/
/*     padding: 10px 0;*/
/* }*/
/* .sf-reset ol li {*/
/*     list-style: decimal;*/
/*     margin-left: 20px;*/
/*     padding: 2px;*/
/*     padding-bottom: 20px;*/
/* }*/
/* .sf-reset ol ol li {*/
/*     list-style-position: inside;*/
/*     margin-left: 0;*/
/*     white-space: nowrap;*/
/*     font-size: 12px;*/
/*     padding-bottom: 0;*/
/* }*/
/* .sf-reset li .selected {*/
/*     background-color: #ffd;*/
/* }*/
/* .sf-button {*/
/*     display: -moz-inline-box;*/
/*     display: inline-block;*/
/*     text-align: center;*/
/*     vertical-align: middle;*/
/*     border: 0;*/
/*     background: transparent none;*/
/*     text-transform: uppercase;*/
/*     cursor: pointer;*/
/*     font: bold 11px Arial, Helvetica, sans-serif;*/
/* }*/
/* .sf-button span {*/
/*     text-decoration: none;*/
/*     display: block;*/
/*     height: 28px;*/
/*     float: left;*/
/* }*/
/* .sf-button .border-l {*/
/*     text-decoration: none;*/
/*     display: block;*/
/*     height: 28px;*/
/*     float: left;*/
/*     padding: 0 0 0 7px;*/
/*     background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAQtJREFUeNpiPHnyJAMakARiByDWYEGT8ADiYGVlZStubm5xlv///4MEQYoKZGRkQkRERLRYWVl5wYJQyXBZWdkwCQkJUxAHKgaWlAHSLqKiosb//v1DsYMFKGCvoqJiDmQzwXTAJYECulxcXNLoumCSoszMzDzoumDGghQwYZUECWIzkrAkSIIGOmlkLI10AiX//P379x8jIyMTNmPf/v79+ysLCwsvuiQoNi5//fr1Kch4dAyS3P/gwYMTQBP+wxwHw0xA4gkQ73v9+vUZdJ2w1Lf82bNn4iCHCQoKasHsZw4ODgbRIL8c+/Lly5M3b978Y2dn5wC6npkFLXnsAOKLjx49AmUHLYAAAwBoQubG016R5wAAAABJRU5ErkJggg==) no-repeat top left;*/
/* }*/
/* .sf-button .border-r {*/
/*     padding: 0 7px 0 0;*/
/*     background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAR1JREFUeNpiPHnyZCMDA8MNID5gZmb2nAEJMH7//v3N169fX969e/cYkL8WqGAHXPLv37//QYzfv39/fvPmzbUnT56sAXInmJub/2H5/x8sx8DCwsIrISFhDmQyPX78+CmQXs70798/BmQsKipqBNTgdvz4cWkmkE5kDATMioqKZkCFdiwg1eiAi4tLGqhQF24nMmBmZuYEigth1QkEbEBxTlySYPvJkwSJ00AnjYylgU6gxB8g/oFVEphkvgLF32KNMmCCewYUv4qhEyj47+HDhyeBzIMYOoEp8CxQw56wsLAncJ1//vz5/P79+2svX74EJc2V4BT58+fPd8CE/QKYHMGJOiIiAp6oWW7evDkNSF8DZYfIyEiU7AAQYACJ2vxVdJW4eQAAAABJRU5ErkJggg==) right top no-repeat;*/
/* }*/
/* .sf-button .btn-bg {*/
/*     padding: 0px 14px;*/
/*     color: #636363;*/
/*     line-height: 28px;*/
/*     background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAcCAYAAACgXdXMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAClJREFUeNpiPnny5EKGf//+/Wf6//8/A4QAcrGzKCZwGc9sa2urBBBgAIbDUoYVp9lmAAAAAElFTkSuQmCC) repeat-x top left;*/
/* }*/
/* .sf-button:hover .border-l,*/
/* .sf-button-selected .border-l {*/
/*     background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAR9JREFUeNpi/P//PwMyOHfunDqQSgNiexZkibNnzxYBqZa3HOs5v7PcYQBLnjlzhg1IbfzIdsTjA/t+ht9Mr8GKwZL//v3r+sB+0OMN+zqIEf8gFMvJkyd1gXTOa9YNDP//otrPAtSV/Jp9HfPff78Z0AEL0LUeXxivMfxD0wXTqfjj/2ugkf+wSrL9/YtpJEyS4S8WI5Ek/+GR/POPFjr//cenE6/kP9q4Fo/kr39/mdj+M/zFkGQCSj5i+ccPjLJ/GBgkuYOHQR1sNDpmAkb2LBmWwL///zKCIxwZM0VHR18G6p4uxeLLAA4tJMwEshiou1iMxXaHLGswA+t/YbhORuQUv2DBAnCifvxzI+enP3dQJUFg/vz5sOzgBBBgAPxX9j0YnH4JAAAAAElFTkSuQmCC) no-repeat top left;*/
/* }*/
/* .sf-button:hover .border-r,*/
/* .sf-button-selected .border-r {*/
/*     background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAcCAYAAACtQ6WLAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAT5JREFUeNpiPHv27BkGBoaDQDzLyMjoJgMSYHrM3WX8hn1d0f///88DFRYhSzIuv2X5H8Rg/SfKIPDTkYH/l80OINffxMTkF9O/f/8ZQPgnwyuGl+wrGd6x7vf49+9fO9jYf3+Bkkj4NesmBqAV+SdPntQC6vzHgIz//gOawbqOGchOxtAJwp8Zr4F0e7D8/fuPAR38/P8eZIo0yz8skv8YvoIk+YE6/zNgAyD7sRqLkPzzjxY6/+HS+R+fTkZ8djLh08lCUCcuSWawJGbwMTGwg7zyBatX2Bj5QZKPsBrLzaICktzN8g/NWEYGZgYZjoC/wMiei5FMpFh8QPSU6Ojoy3Cd7EwiDBJsDgxiLNY7gLrKQGIsHAxSDHxAO2TZ/b8D+TVxcXF9MCtYtLiKLgDpfUDVsxITE1GyA0CAAQA2E/N8VuHyAAAAAABJRU5ErkJggg==) right top no-repeat;*/
/* }*/
/* .sf-button:hover .btn-bg,*/
/* .sf-button-selected .btn-bg {*/
/*     color: #FFFFFF;*/
/*     text-shadow:0 1px 1px #6b9311;*/
/*     background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAcCAIAAAAvP0KbAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAEFJREFUeNpiPnv2LNMdvlymf///M/37B8R/QfQ/MP33L4j+B6Qh7L9//sHpf2h8MA1V+w/KRjYLaDaLCU8vQIABAFO3TxZriO4yAAAAAElFTkSuQmCC) repeat-x top left;*/
/* }*/
/* */
