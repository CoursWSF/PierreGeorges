<?php

// :default:bestRated.html.twig
return array (
);
