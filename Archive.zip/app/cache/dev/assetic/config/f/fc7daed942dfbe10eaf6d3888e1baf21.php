<?php

// :default:rated.html.twig
return array (
);
